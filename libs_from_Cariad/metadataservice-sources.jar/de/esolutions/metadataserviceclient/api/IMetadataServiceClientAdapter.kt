package de.esolutions.metadataserviceclient.api

import android.content.Context
import android.os.Binder
import android.os.DeadObjectException
import android.os.IBinder
import android.os.IInterface
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers
import io.reactivex.rxjava3.core.Observable
import io.reactivex.rxjava3.core.Scheduler
import io.reactivex.rxjava3.core.Single
import kotlin.Boolean
import kotlin.Int
import kotlin.String

/**
 * Generated from [IMetadataService]
 */
class IMetadataServiceClientAdapter internal constructor(
  private val aidl: IMetadataServiceAidl,
  private val context: Context,
  private val scheduler: Scheduler
) : IMetadataService {
  private var requestIdCounter: Int = 0

  private val clientBinder: Binder = Binder()

  private val clientId: Int = aidl.management().registerClient(toString(), clientBinder)

  override fun changeOnlineLookupState(enabled: Boolean): Single<Boolean> = Single.create<Boolean> {
      emitter ->
      val requestId = requestIdCounter++

      try {
          aidl.changeOnlineLookupStateSubscribe(clientId, requestId, enabled, object :
      BooleanSingleCallback.Stub() {
              override fun onSuccess(next: Boolean) = emitter.onSuccess(next)
              override fun onError(message: String) = emitter.onError(RuntimeException(message))
          })
      } catch (e: DeadObjectException) {
          emitter.onError(e)
      }
      emitter.setCancellable {
          try {
              aidl.changeOnlineLookupStateDispose(clientId, requestId)
          } catch (e: DeadObjectException) {
              // NOP since we are trying to dispose anyway and we don't care that service is gone
          }
      }
  }.observeOn(scheduler)

  override fun observeRadioStationData(bearer: StationBearer, cachedLastModified: String):
      Observable<Station> = Observable.create<Station> { emitter ->
      val requestId = requestIdCounter++

      try {
          aidl.observeRadioStationDataSubscribe(clientId, requestId, bearer, cachedLastModified,
      object : StationCallback.Stub() {
              override fun onNext(next: Station) = emitter.onNext(next)
              override fun onComplete() = emitter.onComplete()
              override fun onError(message: String) = emitter.onError(RuntimeException(message))
              override fun attachInterface(owner: IInterface?, descriptor: String?) {
                try { super.attachInterface(owner, descriptor) } catch (e: Exception) {}
              }
          })
      } catch (e: DeadObjectException) {
          emitter.onError(e)
      }
      emitter.setCancellable {
          try {
              aidl.observeRadioStationDataDispose(clientId, requestId)
          } catch (e: DeadObjectException) {
              // NOP since we are trying to dispose anyway and we don't care that service is gone
          }
      }
  }.observeOn(scheduler)

  override fun observeSongRecognition(): Observable<RecognizedSongInfo> =
      Observable.create<RecognizedSongInfo> { emitter ->
      val requestId = requestIdCounter++

      try {
          aidl.observeSongRecognitionSubscribe(clientId, requestId, object :
      RecognizedSongInfoCallback.Stub() {
              override fun onNext(next: RecognizedSongInfo) = emitter.onNext(next)
              override fun onComplete() = emitter.onComplete()
              override fun onError(message: String) = emitter.onError(RuntimeException(message))
              override fun attachInterface(owner: IInterface?, descriptor: String?) {
                try { super.attachInterface(owner, descriptor) } catch (e: Exception) {}
              }
          })
      } catch (e: DeadObjectException) {
          emitter.onError(e)
      }
      emitter.setCancellable {
          try {
              aidl.observeSongRecognitionDispose(clientId, requestId)
          } catch (e: DeadObjectException) {
              // NOP since we are trying to dispose anyway and we don't care that service is gone
          }
      }
  }.observeOn(scheduler)

  override fun getCoverArt(requestData: CoverArtRequestData): Observable<String> =
      Observable.create<String> { emitter ->
      val requestId = requestIdCounter++

      try {
          aidl.getCoverArtSubscribe(clientId, requestId, requestData, object : StringCallback.Stub()
      {
              override fun onNext(next: String) = emitter.onNext(next)
              override fun onComplete() = emitter.onComplete()
              override fun onError(message: String) = emitter.onError(RuntimeException(message))
              override fun attachInterface(owner: IInterface?, descriptor: String?) {
                try { super.attachInterface(owner, descriptor) } catch (e: Exception) {}
              }
          })
      } catch (e: DeadObjectException) {
          emitter.onError(e)
      }
      emitter.setCancellable {
          try {
              aidl.getCoverArtDispose(clientId, requestId)
          } catch (e: DeadObjectException) {
              // NOP since we are trying to dispose anyway and we don't care that service is gone
          }
      }
  }.observeOn(scheduler)

  override fun getPermissionData(): Single<PermissionData> = Single.create<PermissionData> {
      emitter ->
      val requestId = requestIdCounter++

      try {
          aidl.getPermissionDataSubscribe(clientId, requestId, object :
      PermissionDataSingleCallback.Stub() {
              override fun onSuccess(next: PermissionData) = emitter.onSuccess(next)
              override fun onError(message: String) = emitter.onError(RuntimeException(message))
          })
      } catch (e: DeadObjectException) {
          emitter.onError(e)
      }
      emitter.setCancellable {
          try {
              aidl.getPermissionDataDispose(clientId, requestId)
          } catch (e: DeadObjectException) {
              // NOP since we are trying to dispose anyway and we don't care that service is gone
          }
      }
  }.observeOn(scheduler)

  override fun observeRadioStationDataAsia(bearer: StationBearerAsia): Single<StationAsia> =
      Single.create<StationAsia> { emitter ->
      val requestId = requestIdCounter++

      try {
          aidl.observeRadioStationDataAsiaSubscribe(clientId, requestId, bearer, object :
      StationAsiaSingleCallback.Stub() {
              override fun onSuccess(next: StationAsia) = emitter.onSuccess(next)
              override fun onError(message: String) = emitter.onError(RuntimeException(message))
          })
      } catch (e: DeadObjectException) {
          emitter.onError(e)
      }
      emitter.setCancellable {
          try {
              aidl.observeRadioStationDataAsiaDispose(clientId, requestId)
          } catch (e: DeadObjectException) {
              // NOP since we are trying to dispose anyway and we don't care that service is gone
          }
      }
  }.observeOn(scheduler)

  override fun observeSongLyrics(type: Int, familyFriendly: Boolean): Observable<SongLyrics> =
      Observable.create<SongLyrics> { emitter ->
      val requestId = requestIdCounter++

      try {
          aidl.observeSongLyricsSubscribe(clientId, requestId, type, familyFriendly, object :
      SongLyricsCallback.Stub() {
              override fun onNext(next: SongLyrics) = emitter.onNext(next)
              override fun onComplete() = emitter.onComplete()
              override fun onError(message: String) = emitter.onError(RuntimeException(message))
              override fun attachInterface(owner: IInterface?, descriptor: String?) {
                try { super.attachInterface(owner, descriptor) } catch (e: Exception) {}
              }
          })
      } catch (e: DeadObjectException) {
          emitter.onError(e)
      }
      emitter.setCancellable {
          try {
              aidl.observeSongLyricsDispose(clientId, requestId)
          } catch (e: DeadObjectException) {
              // NOP since we are trying to dispose anyway and we don't care that service is gone
          }
      }
  }.observeOn(scheduler)

  override fun getArtistMetadata(artistId: String): Single<MusicMetadata> =
      Single.create<MusicMetadata> { emitter ->
      val requestId = requestIdCounter++

      try {
          aidl.getArtistMetadataSubscribe(clientId, requestId, artistId, object :
      MusicMetadataSingleCallback.Stub() {
              override fun onSuccess(next: MusicMetadata) = emitter.onSuccess(next)
              override fun onError(message: String) = emitter.onError(RuntimeException(message))
          })
      } catch (e: DeadObjectException) {
          emitter.onError(e)
      }
      emitter.setCancellable {
          try {
              aidl.getArtistMetadataDispose(clientId, requestId)
          } catch (e: DeadObjectException) {
              // NOP since we are trying to dispose anyway and we don't care that service is gone
          }
      }
  }.observeOn(scheduler)

  override fun getAlbumMetadata(albumId: String): Single<MusicMetadata> =
      Single.create<MusicMetadata> { emitter ->
      val requestId = requestIdCounter++

      try {
          aidl.getAlbumMetadataSubscribe(clientId, requestId, albumId, object :
      MusicMetadataSingleCallback.Stub() {
              override fun onSuccess(next: MusicMetadata) = emitter.onSuccess(next)
              override fun onError(message: String) = emitter.onError(RuntimeException(message))
          })
      } catch (e: DeadObjectException) {
          emitter.onError(e)
      }
      emitter.setCancellable {
          try {
              aidl.getAlbumMetadataDispose(clientId, requestId)
          } catch (e: DeadObjectException) {
              // NOP since we are trying to dispose anyway and we don't care that service is gone
          }
      }
  }.observeOn(scheduler)

  override fun getRecordingMetadata(recordingId: String): Single<MusicMetadata> =
      Single.create<MusicMetadata> { emitter ->
      val requestId = requestIdCounter++

      try {
          aidl.getRecordingMetadataSubscribe(clientId, requestId, recordingId, object :
      MusicMetadataSingleCallback.Stub() {
              override fun onSuccess(next: MusicMetadata) = emitter.onSuccess(next)
              override fun onError(message: String) = emitter.onError(RuntimeException(message))
          })
      } catch (e: DeadObjectException) {
          emitter.onError(e)
      }
      emitter.setCancellable {
          try {
              aidl.getRecordingMetadataDispose(clientId, requestId)
          } catch (e: DeadObjectException) {
              // NOP since we are trying to dispose anyway and we don't care that service is gone
          }
      }
  }.observeOn(scheduler)

  override fun getRecordingMetadataByName(recordingName: String, artistName: String):
      Single<MusicMetadata> = Single.create<MusicMetadata> { emitter ->
      val requestId = requestIdCounter++

      try {
          aidl.getRecordingMetadataByNameSubscribe(clientId, requestId, recordingName, artistName,
      object : MusicMetadataSingleCallback.Stub() {
              override fun onSuccess(next: MusicMetadata) = emitter.onSuccess(next)
              override fun onError(message: String) = emitter.onError(RuntimeException(message))
          })
      } catch (e: DeadObjectException) {
          emitter.onError(e)
      }
      emitter.setCancellable {
          try {
              aidl.getRecordingMetadataByNameDispose(clientId, requestId)
          } catch (e: DeadObjectException) {
              // NOP since we are trying to dispose anyway and we don't care that service is gone
          }
      }
  }.observeOn(scheduler)

  companion object {
    /**
     * @return a [IMetadataService] or null if the Binder is not available (i.e. [binder] throws a
     * [DeadObjectException])
     */
    fun fromBinder(
      binder: IBinder,
      context: Context,
      scheduler: Scheduler = AndroidSchedulers.mainThread()
    ): IMetadataService? = try {
      IMetadataServiceClientAdapter(IMetadataServiceAidl.Stub.asInterface(binder), context,
          scheduler)
    } catch (e: DeadObjectException) {
      null
    }
  }
}

