package de.esolutions.metadataserviceclient.api

import android.content.Context
import android.os.DeadObjectException
import android.os.IInterface
import android.os.Parcel
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers
import io.reactivex.rxjava3.core.Scheduler
import io.reactivex.rxjava3.disposables.Disposable
import java.lang.Exception
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlin.Boolean
import kotlin.Int
import kotlin.Pair
import kotlin.String
import kotlin.Unit
import kotlin.collections.MutableMap

/**
 * Generated from [IMetadataService] by RpcAidlProviderAdapterRenderer
 *
 * @param onTransactCall this call is executed in the [onTransact] method.
 * Use it to add custom functionality, e.g. multi-user-handling
 */
class IMetadataServiceAidlProviderAdapter(
  private val rpc: IMetadataService,
  private val context: Context,
  private val scheduler: Scheduler = AndroidSchedulers.mainThread(),
  private val onTransactCall: () -> Unit = {}
) : IMetadataServiceAidl.Stub() {
  private var clientCounter: AtomicInteger = AtomicInteger(0)

  private val subscriptions: MutableMap<Pair<Int, Int>, Disposable> = ConcurrentHashMap()

  private val ids: MutableMap<Int, Pair<Int, Int>> = ConcurrentHashMap()

  private val management: IMetadataServiceManagement = object :
      de.esolutions.metadataserviceclient.api.IMetadataServiceManagement.Stub() {
        override fun registerClientWithIds(
          clientName: kotlin.String,
          clientBinder: android.os.IBinder,
          clientUid: kotlin.Int,
          clientPid: kotlin.Int
        ): kotlin.Int {
          val clientId = clientCounter.getAndIncrement()
          clientBinder.linkToDeath({ unregisterClient(clientId, clientName) }, 0)
          ids[clientId] = clientUid to clientPid
          return clientId
        }

        override fun unregisterClient(clientId: kotlin.Int, clientName: kotlin.String) {
          scheduler.scheduleDirect {
            subscriptions.keys.filter { it.first == clientId }
                        .mapNotNull { key -> subscriptions.remove(key) }
                        .forEach { disposable -> disposable.dispose() }
          }
        }

        override fun registerClient(clientName: kotlin.String, clientBinder: android.os.IBinder):
          kotlin.Int = registerClientWithIds(clientName, clientBinder, -1, -1)
      }

  override fun management(): IMetadataServiceManagement = management

  override fun changeOnlineLookupStateSubscribe(
    clientId: Int,
    requestId: Int,
    enabled: Boolean,
    callback: BooleanSingleCallback
  ) {
    scheduler.scheduleDirect {
          subscriptions[clientId to requestId] =
              rpc.changeOnlineLookupState(enabled)
                  .subscribe({
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onSuccess(it)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  }, {
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onError(it.message)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  })}
  }

  override fun observeRadioStationDataSubscribe(
    clientId: Int,
    requestId: Int,
    bearer: StationBearer,
    cachedLastModified: String,
    callback: StationCallback
  ) {
    scheduler.scheduleDirect {
          subscriptions[clientId to requestId] =
              rpc.observeRadioStationData(bearer, cachedLastModified)
                  .subscribe({
                      try {
                          callback.onNext(it)
                      } catch (e: DeadObjectException) {
                          // if the client is dead, we won't emit to it anymore
                          subscriptions.remove(clientId to requestId)
                              ?.dispose()
                      }
                  }, {
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onError(it.message)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  }, {
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onComplete()
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  })}
  }

  override fun observeSongRecognitionSubscribe(
    clientId: Int,
    requestId: Int,
    callback: RecognizedSongInfoCallback
  ) {
    scheduler.scheduleDirect {
          subscriptions[clientId to requestId] =
              rpc.observeSongRecognition()
                  .subscribe({
                      try {
                          callback.onNext(it)
                      } catch (e: DeadObjectException) {
                          // if the client is dead, we won't emit to it anymore
                          subscriptions.remove(clientId to requestId)
                              ?.dispose()
                      }
                  }, {
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onError(it.message)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  }, {
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onComplete()
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  })}
  }

  override fun getCoverArtSubscribe(
    clientId: Int,
    requestId: Int,
    requestData: CoverArtRequestData,
    callback: StringCallback
  ) {
    scheduler.scheduleDirect {
          subscriptions[clientId to requestId] =
              rpc.getCoverArt(requestData)
                  .subscribe({
                      try {
                          callback.onNext(it)
                      } catch (e: DeadObjectException) {
                          // if the client is dead, we won't emit to it anymore
                          subscriptions.remove(clientId to requestId)
                              ?.dispose()
                      }
                  }, {
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onError(it.message)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  }, {
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onComplete()
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  })}
  }

  override fun getPermissionDataSubscribe(
    clientId: Int,
    requestId: Int,
    callback: PermissionDataSingleCallback
  ) {
    scheduler.scheduleDirect {
          subscriptions[clientId to requestId] =
              rpc.getPermissionData()
                  .subscribe({
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onSuccess(it)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  }, {
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onError(it.message)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  })}
  }

  override fun observeRadioStationDataAsiaSubscribe(
    clientId: Int,
    requestId: Int,
    bearer: StationBearerAsia,
    callback: StationAsiaSingleCallback
  ) {
    scheduler.scheduleDirect {
          subscriptions[clientId to requestId] =
              rpc.observeRadioStationDataAsia(bearer)
                  .subscribe({
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onSuccess(it)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  }, {
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onError(it.message)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  })}
  }

  override fun observeSongLyricsSubscribe(
    clientId: Int,
    requestId: Int,
    type: Int,
    familyFriendly: Boolean,
    callback: SongLyricsCallback
  ) {
    scheduler.scheduleDirect {
          subscriptions[clientId to requestId] =
              rpc.observeSongLyrics(type, familyFriendly)
                  .subscribe({
                      try {
                          callback.onNext(it)
                      } catch (e: DeadObjectException) {
                          // if the client is dead, we won't emit to it anymore
                          subscriptions.remove(clientId to requestId)
                              ?.dispose()
                      }
                  }, {
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onError(it.message)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  }, {
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onComplete()
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  })}
  }

  override fun getArtistMetadataSubscribe(
    clientId: Int,
    requestId: Int,
    artistId: String,
    callback: MusicMetadataSingleCallback
  ) {
    scheduler.scheduleDirect {
          subscriptions[clientId to requestId] =
              rpc.getArtistMetadata(artistId)
                  .subscribe({
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onSuccess(it)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  }, {
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onError(it.message)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  })}
  }

  override fun getAlbumMetadataSubscribe(
    clientId: Int,
    requestId: Int,
    albumId: String,
    callback: MusicMetadataSingleCallback
  ) {
    scheduler.scheduleDirect {
          subscriptions[clientId to requestId] =
              rpc.getAlbumMetadata(albumId)
                  .subscribe({
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onSuccess(it)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  }, {
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onError(it.message)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  })}
  }

  override fun getRecordingMetadataSubscribe(
    clientId: Int,
    requestId: Int,
    recordingId: String,
    callback: MusicMetadataSingleCallback
  ) {
    scheduler.scheduleDirect {
          subscriptions[clientId to requestId] =
              rpc.getRecordingMetadata(recordingId)
                  .subscribe({
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onSuccess(it)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  }, {
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onError(it.message)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  })}
  }

  override fun getRecordingMetadataByNameSubscribe(
    clientId: Int,
    requestId: Int,
    recordingName: String,
    artistName: String,
    callback: MusicMetadataSingleCallback
  ) {
    scheduler.scheduleDirect {
          subscriptions[clientId to requestId] =
              rpc.getRecordingMetadataByName(recordingName, artistName)
                  .subscribe({
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onSuccess(it)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  }, {
                      subscriptions.remove(clientId to requestId)
                      try {
                          callback.onError(it.message)
                      } catch (e: DeadObjectException) {
                          // NOP since if the client is dead, we won't emit to it anymore
                      }
                  })}
  }

  override fun changeOnlineLookupStateDispose(clientId: Int, requestId: Int) {
    scheduler.scheduleDirect {
      subscriptions.remove(clientId to requestId)?.dispose()
    }
  }

  override fun observeRadioStationDataDispose(clientId: Int, requestId: Int) {
    scheduler.scheduleDirect {
      subscriptions.remove(clientId to requestId)?.dispose()
    }
  }

  override fun observeSongRecognitionDispose(clientId: Int, requestId: Int) {
    scheduler.scheduleDirect {
      subscriptions.remove(clientId to requestId)?.dispose()
    }
  }

  override fun getCoverArtDispose(clientId: Int, requestId: Int) {
    scheduler.scheduleDirect {
      subscriptions.remove(clientId to requestId)?.dispose()
    }
  }

  override fun getPermissionDataDispose(clientId: Int, requestId: Int) {
    scheduler.scheduleDirect {
      subscriptions.remove(clientId to requestId)?.dispose()
    }
  }

  override fun observeRadioStationDataAsiaDispose(clientId: Int, requestId: Int) {
    scheduler.scheduleDirect {
      subscriptions.remove(clientId to requestId)?.dispose()
    }
  }

  override fun observeSongLyricsDispose(clientId: Int, requestId: Int) {
    scheduler.scheduleDirect {
      subscriptions.remove(clientId to requestId)?.dispose()
    }
  }

  override fun getArtistMetadataDispose(clientId: Int, requestId: Int) {
    scheduler.scheduleDirect {
      subscriptions.remove(clientId to requestId)?.dispose()
    }
  }

  override fun getAlbumMetadataDispose(clientId: Int, requestId: Int) {
    scheduler.scheduleDirect {
      subscriptions.remove(clientId to requestId)?.dispose()
    }
  }

  override fun getRecordingMetadataDispose(clientId: Int, requestId: Int) {
    scheduler.scheduleDirect {
      subscriptions.remove(clientId to requestId)?.dispose()
    }
  }

  override fun getRecordingMetadataByNameDispose(clientId: Int, requestId: Int) {
    scheduler.scheduleDirect {
      subscriptions.remove(clientId to requestId)?.dispose()
    }
  }

  override fun attachInterface(owner: IInterface?, descriptor: String?) {
    try { super.attachInterface(owner, descriptor) } catch (e: Exception) {}
  }

  override fun onTransact(
    code: Int,
    data: Parcel,
    reply: Parcel?,
    flags: Int
  ): Boolean {
    onTransactCall()
    return super.onTransact(code, data, reply, flags)
  }
}

